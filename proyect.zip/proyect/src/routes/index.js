const {Router}=require('express');
const router = Router();
const stripe =require ('stripe')('sk_test_eedf18s2LBCxsO3DCMrPXzal00BDQsK91o') //conectar la app con clave secreta

router.get('/',(req,res)=>{
   res.render('index');
});

// obtener los datos del comprador - con datos asincronos denora en procesamiento de verificacion 
router.post('/checkout', async(req,res)=>{
   console.log(req.body);
  
  const customer = await stripe.customers.create({
  email: req.body.stripeEmail,
  source: req.body.stripeToken
  });
  // res.send('recibido');

//obteniendo el tipo de moneda
  const charge = await stripe.charges.create({
    amount:'3000',
    currency:'usd',
    customer: customer.id,
    description:'juego de futbol'
  });

    console.log(charge.id);    //mostrar traspaso 
 
    //res.render('download');
     // reutilizacion para los archivos de descargas del servidor

    res.send('resivido');
});

module.exports = router;