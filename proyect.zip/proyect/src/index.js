//modulos
const express =require('express');
const expbhs = require('express-handlebars'); //plantilla
const path = require('path'); 

//inicializacion 
const app = express ();


//configuraciones
app.set('views', path.join(__dirname, 'views'));
app.engine('.hbs',expbhs ({
    defaultLayout:'main',
    layoutsDir:path.join(app.get('views'), 'layouts'),
    partialsDir:path.join(app.get('views'), 'partials'),
    extname: '.hbs' // buscar la extencion del archicvo
}));

app.set('view engine', '.hbs');


// recibir desde el servidor datps json
app.use(express.static(__dirname + '/public'));
app.use(express.urlencoded({extended:false }));
app.use(express.json());

// ruta del servidor
app.use(require('./routes/index'));

//carpeta de archibos publicos (public)
// app.use(express.static(path.join(__dirname, 'public')));

app.listen(3006,()=>{
    console.log('serve on port')
});



